
-- --------------------------------------------------------

--
-- Structure de la table `entreprise`
--

DROP TABLE IF EXISTS `entreprise`;
CREATE TABLE IF NOT EXISTS `entreprise` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `siret` varchar(50) NOT NULL,
  `dividende` varchar(50) NOT NULL,
  `image` blob NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `entreprise`
--

INSERT INTO `entreprise` (`id`, `nom`, `siret`, `dividende`, `image`) VALUES
(1, 'Iknsa', '0123565656565', 'test', 0x2e2f75706c6f6164732f696d6733202d20436f70792e706e67),
(2, 'SND', '0123565656565', '140', 0x2e2f75706c6f6164732f696d6733202d20436f70792e706e67),
(3, 'Aston', '789636441', '45630', 0x2e2f75706c6f6164732f696d6733202d20436f70792e706e67);
