
-- --------------------------------------------------------

--
-- Structure de la table `etudiant`
--

DROP TABLE IF EXISTS `etudiant`;
CREATE TABLE IF NOT EXISTS `etudiant` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) CHARACTER SET utf8 NOT NULL,
  `prenom` varchar(20) CHARACTER SET utf8 NOT NULL,
  `email` varchar(30) CHARACTER SET utf8 NOT NULL,
  `password` text CHARACTER SET utf8 NOT NULL,
  `fonction` varchar(30) CHARACTER SET utf8 NOT NULL,
  `telephone` int(10) NOT NULL,
  `adresse` varchar(60) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `etudiant`
--

INSERT INTO `etudiant` (`id`, `nom`, `prenom`, `email`, `password`, `fonction`, `telephone`, `adresse`) VALUES
(1, 'Ochoa', 'Veroncia', 'veronikot11@yahoo.fr', '$2y$10$qWUoreyyB0e.mymeXSCbmeoyVRRpfyGDQk0AXb9sjOqPdpbB9Ws62', 'Chercheuse', 786011897, 'Henri Corvol'),
(2, 'Yebda', 'Sabrina', 'yebda.sabrina@gmail.com ', '$2y$10$F3SUKeVUInEvycxIkG86c.XECA9OS2yb0jWOH3Ol.Sfne1fFp/rci', 'Etudiante', 562148971, 'Kremblim'),
(4, 'Gillot', 'Jeremy', 'jeremy.gillot@gmail.com', '$2y$10$RshxDfSyLlCDaqMOtqpIZucyDrvXlMRu0NyCtuZo22fd8kQgtnX7m', 'Etudiant', 985467217, 'La Defense'),
(6, 'OCHOA', 'Veronica', 'thi.fendian@gmail.com', '$2y$10$EzpVkHtTG1IuQq0P7Ns/JO/VmLeLgQPj2fsZYvR1A5YJF/exzyn2.', 'Infographist', 123658959, 'Cachan'),
(7, 'Perez', 'Laura', 'laura@hotmail.com', '$2y$10$0tQIHnFrBJr1hnGJIOzrw.Kv.ZvqYPfimaex8INX7Qza/ivAHEqq2', 'Etudiante', 123658959, 'La Defense'),
(8, 'Rossignol', 'Charline', 'charline.rossignol@outlook.f', '$2y$10$OSIUxcA8A76G3tsPM6ZUJ.L.RHPgElwhUuMHgnuRJawZjM3wciWQS', 'Etudiante', 123658959, 'fleurs'),
(14, 'Gillot', 'Thierry1', 'test@test.fr', '$2y$10$x0qr55Eki8C9WfMWW14d/upMil2CAF6xj0skwEyP1Q2ctJ/pacF32', 'dev', 123658959, 'Robinson'),
(15, 'Lopez', 'Monica', 'monicalopez@yahoo;fr', '$2y$10$Hgh0pyQQiZye3G/.FbJsQOALc9bzmZ8L3ymAkmAgiXDaCc00OP3GK', 'Comerciante', 123568965, 'Chatelet'),
(16, 'Ochoa', 'Veronica', 'beronik@hotmail.com', '$2y$10$A0YpIry./nDHkTURoPzZcuJKyPSp5ucdBSmhCf9USUKIibbdRCUWu', 'Chercheuse', 786011897, 'Choisy le Roi'),
(18, 'Camara2', 'Moussa', 'tinto@yahoo.fr', '$2y$10$y10p/fi2e4D.oL2SQDvp3eZ8zuML0RsuJxqisJJY7HGiSZ6UhzgKq', 'prof', 123564897, 'Paris');
