
-- --------------------------------------------------------

--
-- Structure de la table `post`
--

DROP TABLE IF EXISTS `post`;
CREATE TABLE IF NOT EXISTS `post` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `summary` text COLLATE utf8_unicode_ci,
  `content` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `extension` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5A8A6C8DA76ED395` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `post`
--

INSERT INTO `post` (`id`, `title`, `summary`, `content`, `created_at`, `user_id`, `extension`) VALUES
(4, 'La nature', 'hgjhzgjhz', 'aze ,en b,a', '2012-01-01 00:00:00', 4, NULL),
(5, 'Les bateaux', 'Como estas', 'Me gustan los barcos', '2012-01-01 00:00:00', 4, NULL),
(6, 'Le travail', 'L\'informatique', 'hjkhzfkhkf', '2015-01-03 00:00:00', 4, NULL),
(7, 'tets', 'tets', 'khfkgfia', '2017-12-13 09:08:00', 4, 'png'),
(8, 'Le football', 'Les jeux de balle au pied existent dès l\'Antiquité', 'jkjkjlk', '2017-12-13 13:24:54', 4, 'png');
