
-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

DROP TABLE IF EXISTS `comment`;
CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `post_id` int(11) DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9474526CA76ED395` (`user_id`),
  KEY `IDX_9474526C4B89032C` (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `comment`
--

INSERT INTO `comment` (`id`, `user_id`, `post_id`, `comment`, `created_at`) VALUES
(1, NULL, NULL, 'fsdgfghgfh', '2017-12-13 12:34:31'),
(2, 4, 7, 'frghjkl', '2017-12-13 12:34:42'),
(3, 4, 7, 'vero', '2017-12-13 12:34:53'),
(4, 4, 7, 'nica', '2017-12-13 12:35:01'),
(5, 4, 7, 'comment', '2017-12-13 12:35:08'),
(6, 4, 7, 'kghfghsdfsjkghfsdfd', '2017-12-13 13:18:16'),
(7, NULL, NULL, 'jgjzhgfrjhe', '2017-12-13 13:40:15'),
(8, NULL, NULL, 'gfsg', '2017-12-13 13:49:06'),
(9, NULL, NULL, 'hola', '2017-12-13 13:56:07');
