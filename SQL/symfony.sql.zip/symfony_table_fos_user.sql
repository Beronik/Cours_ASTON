
-- --------------------------------------------------------

--
-- Structure de la table `fos_user`
--

DROP TABLE IF EXISTS `fos_user`;
CREATE TABLE IF NOT EXISTS `fos_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `username_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `email_canonical` varchar(180) COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `salt` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `confirmation_token` varchar(180) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_requested_at` datetime DEFAULT NULL,
  `roles` longtext COLLATE utf8_unicode_ci NOT NULL COMMENT '(DC2Type:array)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_957A647992FC23A8` (`username_canonical`),
  UNIQUE KEY `UNIQ_957A6479A0D96FBF` (`email_canonical`),
  UNIQUE KEY `UNIQ_957A6479C05FB297` (`confirmation_token`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `fos_user`
--

INSERT INTO `fos_user` (`id`, `username`, `username_canonical`, `email`, `email_canonical`, `enabled`, `salt`, `password`, `last_login`, `confirmation_token`, `password_requested_at`, `roles`) VALUES
(1, 'Veronica', 'veronica', 'beronik@hotmail.com', 'beronik@hotmail.com', 1, NULL, '$2y$13$KTGC6A3YH1MUl1QWJaGh7uNWrPOoORqHBPBkjFhoVactLZwWOgt5.', '2017-12-07 15:43:05', NULL, NULL, 'a:0:{}'),
(2, 'aston', 'aston', 'test@test.com', 'test@test.com', 1, NULL, '$2y$13$qnl194xKQ1G3A9xNE4vrqOcak6kgGzLRCsGlLiOl7YQRf5EDXySFK', '2017-12-07 16:08:06', NULL, NULL, 'a:0:{}'),
(4, 'Moussa', 'moussa', 'titon', 'titon', 1, NULL, '$2y$13$CZdlu1FOd5rFyzzmRbyJQuK1M7CVoAyo20gzdyJCIZ2vUZacEEhnO', '2017-12-19 08:51:25', NULL, NULL, 'a:1:{i:0;s:10:\"ROLE_ADMIN\";}');
