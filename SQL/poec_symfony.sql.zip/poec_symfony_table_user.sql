
-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(30) NOT NULL,
  `prenom` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `fonction` varchar(25) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`Id`, `nom`, `prenom`, `email`, `adresse`, `fonction`) VALUES
(4, 'Charline', 'Rossignol', 'charline.rossignol@outlook.f', 'Les Roses', 'Etudiante'),
(12, 'Ochoa', 'Veronica', 'veronikot11@yahoo.fr', 'Henri Corvol', 'Chercheuse');
