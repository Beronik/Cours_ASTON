-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 22 déc. 2017 à 15:02
-- Version du serveur :  5.7.19
-- Version de PHP :  5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `revue`
--
CREATE DATABASE IF NOT EXISTS `revue` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `revue`;

-- --------------------------------------------------------

--
-- Structure de la table `article`
--

DROP TABLE IF EXISTS `article`;
CREATE TABLE IF NOT EXISTS `article` (
  `idArticle` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(255) DEFAULT NULL,
  `contenu` longtext,
  PRIMARY KEY (`idArticle`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article`
--

INSERT INTO `article` (`idArticle`, `titre`, `contenu`) VALUES
(1, 'Titre article 1', 'bla bla bla'),
(2, 'Titre article 2', 'bla bla bla'),
(3, 'Titre article 3', 'bla bla bla'),
(4, 'Titre article 4', 'bla bla bla'),
(5, 'Titre article 5', 'bla bla bla'),
(6, 'Titre article 6', 'bla bla bla'),
(7, 'Le Monde', 'ta tat tat');

-- --------------------------------------------------------

--
-- Structure de la table `article_est_publie`
--

DROP TABLE IF EXISTS `article_est_publie`;
CREATE TABLE IF NOT EXISTS `article_est_publie` (
  `ARTICLE_id` int(11) NOT NULL,
  `NUMERO_id` int(11) NOT NULL,
  `pageDebut` int(11) DEFAULT NULL,
  `pageFin` int(11) DEFAULT NULL,
  PRIMARY KEY (`ARTICLE_id`,`NUMERO_id`),
  KEY `fk_ARTICLE_has_NUMERO_NUMERO1_idx` (`NUMERO_id`),
  KEY `fk_ARTICLE_has_NUMERO_ARTICLE1_idx` (`ARTICLE_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `article_est_publie`
--

INSERT INTO `article_est_publie` (`ARTICLE_id`, `NUMERO_id`, `pageDebut`, `pageFin`) VALUES
(1, 1, 3, 6),
(1, 2, 7, 10),
(3, 1, 5, 16),
(3, 3, 5, 16),
(4, 4, 5, 16),
(6, 7, 5, 16);

-- --------------------------------------------------------

--
-- Structure de la table `article_fait_reference`
--

DROP TABLE IF EXISTS `article_fait_reference`;
CREATE TABLE IF NOT EXISTS `article_fait_reference` (
  `ArticleId_Src` int(11) NOT NULL,
  `ArticleId_Ref` int(11) NOT NULL,
  PRIMARY KEY (`ArticleId_Src`,`ArticleId_Ref`),
  KEY `fk_ARTICLE_has_ARTICLE_ARTICLE1_idx` (`ArticleId_Ref`),
  KEY `fk_ARTICLE_has_ARTICLE_ARTICLE_idx` (`ArticleId_Src`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Structure de la table `auteur`
--

DROP TABLE IF EXISTS `auteur`;
CREATE TABLE IF NOT EXISTS `auteur` (
  `idAuteur` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `prenom` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idAuteur`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auteur`
--

INSERT INTO `auteur` (`idAuteur`, `nom`, `prenom`, `email`) VALUES
(1, 'Dupont', 'Jean', 'secret@aol.com'),
(2, 'Durant', 'Henry', 'secret@aol.com'),
(3, 'Jhons', 'Indiana', 'secret@aol.com');

-- --------------------------------------------------------

--
-- Structure de la table `auteur_ecrit`
--

DROP TABLE IF EXISTS `auteur_ecrit`;
CREATE TABLE IF NOT EXISTS `auteur_ecrit` (
  `AUTEUR_id` int(11) NOT NULL,
  `ARTICLE_id` int(11) NOT NULL,
  PRIMARY KEY (`AUTEUR_id`,`ARTICLE_id`),
  KEY `fk_AUTEUR_has_ARTICLE_ARTICLE1_idx` (`ARTICLE_id`),
  KEY `fk_AUTEUR_has_ARTICLE_AUTEUR1_idx` (`AUTEUR_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `auteur_ecrit`
--

INSERT INTO `auteur_ecrit` (`AUTEUR_id`, `ARTICLE_id`) VALUES
(1, 1),
(1, 2),
(2, 3),
(2, 4),
(3, 5),
(3, 6);

-- --------------------------------------------------------

--
-- Structure de la table `publication`
--

DROP TABLE IF EXISTS `publication`;
CREATE TABLE IF NOT EXISTS `publication` (
  `idNumero` int(11) NOT NULL AUTO_INCREMENT,
  `annee` varchar(4) DEFAULT NULL,
  `nbPages` int(11) DEFAULT NULL,
  `REVUE_id` int(11) NOT NULL,
  PRIMARY KEY (`idNumero`),
  KEY `fk_PUBLICATION_REVUE1_idx` (`REVUE_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `publication`
--

INSERT INTO `publication` (`idNumero`, `annee`, `nbPages`, `REVUE_id`) VALUES
(1, '2013', 5, 1),
(2, '2012', 7, 1),
(3, '2014', 5, 2),
(4, '2016', 5, 3),
(5, '2004', 5, 1),
(6, '2004', 15, 1),
(7, '2004', 15, 4);

-- --------------------------------------------------------

--
-- Structure de la table `revue`
--

DROP TABLE IF EXISTS `revue`;
CREATE TABLE IF NOT EXISTS `revue` (
  `idRevue` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(255) DEFAULT NULL,
  `periodicite` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`idRevue`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `revue`
--

INSERT INTO `revue` (`idRevue`, `nom`, `periodicite`) VALUES
(1, 'Linux Magazine', 1),
(2, 'Windows', 1),
(3, 'Informatique', 1),
(4, 'l\'histoire', 2);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `article_est_publie`
--
ALTER TABLE `article_est_publie`
  ADD CONSTRAINT `fk_ARTICLE_has_NUMERO_ARTICLE1` FOREIGN KEY (`ARTICLE_id`) REFERENCES `article` (`idArticle`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ARTICLE_has_NUMERO_NUMERO1` FOREIGN KEY (`NUMERO_id`) REFERENCES `publication` (`idNumero`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `article_fait_reference`
--
ALTER TABLE `article_fait_reference`
  ADD CONSTRAINT `fk_ARTICLE_has_ARTICLE_ARTICLE` FOREIGN KEY (`ArticleId_Src`) REFERENCES `article` (`idArticle`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_ARTICLE_has_ARTICLE_ARTICLE1` FOREIGN KEY (`ArticleId_Ref`) REFERENCES `article` (`idArticle`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `auteur_ecrit`
--
ALTER TABLE `auteur_ecrit`
  ADD CONSTRAINT `fk_AUTEUR_has_ARTICLE_ARTICLE1` FOREIGN KEY (`ARTICLE_id`) REFERENCES `article` (`idArticle`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_AUTEUR_has_ARTICLE_AUTEUR1` FOREIGN KEY (`AUTEUR_id`) REFERENCES `auteur` (`idAuteur`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `publication`
--
ALTER TABLE `publication`
  ADD CONSTRAINT `fk_PUBLICATION_REVUE1` FOREIGN KEY (`REVUE_id`) REFERENCES `revue` (`idRevue`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
