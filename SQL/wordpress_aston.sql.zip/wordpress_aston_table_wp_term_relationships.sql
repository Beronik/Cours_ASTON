
-- --------------------------------------------------------

--
-- Structure de la table `wp_term_relationships`
--

DROP TABLE IF EXISTS `wp_term_relationships`;
CREATE TABLE IF NOT EXISTS `wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;

--
-- Déchargement des données de la table `wp_term_relationships`
--

INSERT INTO `wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(138, 2, 0),
(130, 2, 0),
(128, 2, 0),
(127, 2, 0),
(121, 2, 0),
(48, 2, 0),
(105, 2, 0),
(111, 2, 0),
(114, 2, 0),
(115, 2, 0),
(113, 2, 0),
(116, 2, 0),
(112, 2, 0),
(108, 2, 0),
(107, 2, 0),
(117, 2, 0),
(110, 2, 0),
(109, 2, 0),
(137, 2, 0),
(159, 1, 0),
(162, 1, 0);
